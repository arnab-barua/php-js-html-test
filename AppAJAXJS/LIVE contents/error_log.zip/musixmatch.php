<?php
	//$link = trim($_POST["link"]);
	include('simple_html_dom.php');
	
	$link= "https://www.musixmatch.com/lyrics/The-Lonely-Biscuits/Long-Day";
	echo $link;
	$html = file_get_html($link);
	//$displaybody = $html->find('section[id=maincontent]', 0);
	$displaybody = $html->find('div[class=mxm-lyrics]', 1)->plaintext;
	echo $displaybody;
?>